<p float="left">

<img src="./img/artemis.png" style="vertical-align: center;" width="100"/><img src="./img/ods_logo.jpg" style="vertical-align: center;" width="100"/>

</p>
<!-- README.md is generated from README.Rmd. Please edit that file -->

For the version of this package which uses DatabaseConnector, please
change branches to
[“DatabaseConnector”](https://github.com/OdyOSG/ARTEMIS/tree/DatabaseConnector).

## Overview

ARTEMIS provides an interface for utilizing a modified Temporal
Smith-Waterman (TSW) algorithm, derived from
[10.1109/DSAA.2015.7344785](https://www.researchgate.net/publication/292331949_Temporal_Needleman-Wunsch),
to summarize longitudinal EHR data into discrete regimen eras. Primarily
intended to be used for cancer patients, ARTEMIS utilizes data derived
from the [HemOnc](https://hemonc.org/wiki/Main_Page) oncology reference
to form the basic regimen data used in testing.

<figure>
<img src="/img/Workflow_Detailed.png?" alt="ARTEMIS Workflow" />
<figcaption aria-hidden="true">ARTEMIS Workflow</figcaption>
</figure>

## Features

ARTEMIS is primarily useful for stratifying patients based on their most
likely prescribed regimens, for use in cohort construction via the
Episode Era table of the [OMOP
CDM](https://www.ohdsi.org/data-standardization/).

ARTEMIS may also be used for providing summary statistics on the number
and distribution of regimens found within a specific cohort, as well as
their coverage and length, as well as providing summary graphics for
patient treatment trajectories.

<figure>
<img src="/img/Networks.png?" alt="Treatment Trajectories" />
<figcaption aria-hidden="true">Treatment Trajectories</figcaption>
</figure>

## Installation

ARTEMIS can presently be installed directly from GitHub:

    # install.packages("devtools")
    devtools::install_github("odyOSG/ARTEMIS")

ARTEMIS relies on a python back-end via
[reticulate](https://rstudio.github.io/reticulate/) and depending on
your reticulate settings, system and environment, you may need to run
the following commands before loading the package:

    #reticulate::py_install("numpy")
    #reticulate::py_install("pandas")

If you do not presently have reticulate or python3.11 installed you may
first need to run the following commands to ensure that reticulate can
access a valid python install on your system:

    install.packages("reticulate")
    library(reticulate)

This will prompt reticulate to install python, create a local virtualenv
called “r-reticulate” and finally set that as the local virtual
environment for use when running python via R.

## Usage

### CDMConnector

ARTEMIS also relies on the package
[CDMConnector](https://darwin-eu.github.io/CDMConnector/) to create a
connection to your CDM from any valid DBI connection. The process of
cohort creation requires that you have a valid data-containing schema,
and a pre-existing schema where you have write access. This write schema
will be used to store cohort tables during their generation, and may be
safely deleted after running the package.

The specific drivers required by dbConnect may change depending on your
system. More detailed information can be found in the section “DBI
Drivers” at the bottom of this readme.

If the OHDSI package [CirceR](https://github.com/OHDSI/CirceR) is not
already installed on your system, you may need to directly install this
from the OHDSI/CirceR github page, as this is a non-CRAN dependency
required by CDMConnector.

    dbiconn <- DBI::dbConnect(RPostgres::Redshift(),
                              dbname = "dbName",
                              host = "hostName",
                              port = "9999",
                              user = "user",
                              password = "password")

    cdmSchema      <- "schema_containing_data"

    cdm <- CDMConnector::cdm_from_con(con = dbiconn,
                                      cdm_schema = cdmSchema,
                                      write_schema = "schema_with_write_access")

### Input

An input JSON containing a cohort specification is input by the user.
Information on OHDSI cohort creation and best practices can be found
[here](https://ohdsi.github.io/TheBookOfOhdsi/Cohorts.html).

    json <- loadCohort()
    name <- "examplecohort"

    #Manual
    #json <- CDMConnector::readCohortSet(path = here::here("myCohort/"))
    #name <- "customcohort"

Regimen data may be read in from the provided package, or may be
submitted directly by the user. All of the provided regimens will be
tested against all patients within a given cohort.

    regimens <- loadRegimens(condition = "lungCancer")

    #Manual
    #regimens <- read.csv(here::here("data/myRegimens.csv"))

A set of valid drugs may also be read in using the provided data, or may
be curated and submitted by the user. Only valid drugs will appear in
processed patient strings.

    validDrugs <- loadDrugs()

    #Manual
    #validDrugs <- read.csv(here::here("data/myDrugs.csv"))

### Pipeline

The cdm connection is used to generate a dataframe containing the
relevant patient details for constructing regimen strings.

    con_df <- getCohortSet(cdm = cdm, json = json, name = name)

Regimen strings are then constructed, collated and filtered into a
stringDF dataframe containing all patients of interest.

    stringDF <- stringDF_from_cdm(con_df = con_df, writeOut = F, validDrugs = validDrugs)

    stringDF <- stringDF %>% filter_stringDF(min = 20)

The TSW algorithm is then run using user input settings and the provided
regimen and patient data. Detailed information on user inputs, such as
the gap penalty, g, can be found [here](www.github.com/odyOSG/ARTEMIS)

    output_all <- stringDF %>% generateRawAlignments(regimens = regimens,
                                                     g = 0.4,
                                                     Tfac = 0.5,
                                                     verbose = 0,
                                                     mem = -1,
                                                     removeOverlap = 1,
                                                     method = "PropDiff")

Raw output alignments are then post-processed and may be visualised.
Post-processing steps include the handling and combination of
overlapping regimen alignments, as well as formatting output for
submission to an episode era table.

    processedAll <- output_all %>% processAlignments(regimenCombine = 28, regimens = regimens)

    personOfInterest <- output_all[output_all$personID == unique(output_all$personID)[1337],]

    plotOutput(personOfInterest, fontSize = 2.5)

Data may then be further explored via several graphics which indicate
various information, such as regimen frequency or the score/length
distributions of a given regimen.

    plotFrequency(processedAll)

    plotScoreDistribution(regimen1 = "Acetaminophen Monotherapy", regimen2 = "Ibuprofen Monotherapy", processedAll = processedAll)

    plotRegimenLengthDistribution(regimen1 = "Acetaminophen Monotherapy", regimen2 = "Ibuprofen Monotherapy", processedAll = processedAll)

Treatment trajectories, or regimen eras, can then be calculated, adding
further information about the relative sequencing order of different
regimens and regimen types.

    processedEras <- processedAll %>% calculateEras(discontinuationTime = 90)

    regStats <- processedEras %>% generateRegimenStats()

    regStats[,-c(4,7)]

And resulting graphics, such as a sankey indicating the overall patterns
of treatment trajectories can then be constructed. plotSankey() produces
both a saved .png as well as an interactable .html of the created
network graph.

You may need to run webshot::install\_phantomjs() if your system does
not already have it installed to utilise the Sankey package.

    plotErasFrequency(processedEras)

    #Potential dependency install:
    #webshot::install_phantomjs()

    regimen_Groups <- loadGroups()
    plotSankey(processedEras, regimen_Groups)

### Output

Finally, a set of outputs may be produced and written into a local file
using the writeOutputs() function. No patient IDs are written as
outputs, with anonymised random IDs being used in their place. Both
writeOuputs() and plotSankey() produce outputs that are automatically
saved to the local working directory.

writeOutputs also produces data about the underlying cohorts used to
construct the regimen outputs, and so also requires a call to the cdm
directly.

    writeOutputs(output_all = output_all, output_processed = processedAll, output_eras = processedEras,
                cdm = cdm, con_df = con_df, regGroups = regimen_Groups,
                regStats = regStats, stringDF = stringDF)

## DBI Drivers

CDMConnector is tested using the following DBI driver backends:

-   [RPostgres](https://rpostgres.r-dbi.org/reference/postgres) on
    Postgres and Redshift
-   [odbc](https://solutions.posit.co/connections/db/r-packages/odbc/)
    on Microsoft SQL Server, Oracle, and Databricks/Spark
-   [duckdb](https://duckdb.org/docs/api/r)

## Getting help

If you encounter a clear bug, please file an issue with a minimal
[reproducible example](https://reprex.tidyverse.org/) at the [GitHub
issues page](https://github.com/OdyOSG/ARTEMIS/issues).
